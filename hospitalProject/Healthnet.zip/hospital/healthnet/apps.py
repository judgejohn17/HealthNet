from django.apps import AppConfig


class HealthnetConfig(AppConfig):
    name = 'healthnet'
