from django.db import models
from django.contrib.auth.models import User
import datetime
from django.core.validators import RegexValidator, MinValueValidator


class Patient(User):
    class Meta:
        #Without this, the Patient class inherits the verbose name of the User.
        #This causes it to appear as "User" in the admin site.
        verbose_name = "Patient";

    insurance_plan = models.ForeignKey('InsurancePlan')
    date_of_birth = models.DateField(default=0)
    phone_number = models.CharField(max_length=10, validators=[
        RegexValidator('[0-9]{10}',"Must be 10 digits, numbers only")])
    contact_first_name = models.CharField(max_length=50,blank=True)
    contact_last_name = models.CharField(max_length=50,blank=True)
    contact_phone_number = models.CharField(max_length=10,blank=True,validators=[
        RegexValidator('[0-9]{10}|^$',"Must be 10 digits, numbers only")])

    def save(self):
        LogItem(subject = self, action = 0, time = datetime.datetime.now()).save()
        User.save(self)

    def __repr__(self):
        return repr([self.first_name, self.last_name, self.username, self.password, self.email, self.insurance_plan,
                     self.date_of_birth, self.phone_number, self.emergency_contact])


class Employee(User):
    salary = models.IntegerField(validators=[MinValueValidator(0,"Must not be negative")])


class HospitalAdministrator(Employee):
    class Meta:
        #Without this, the HospitalAdministrator class inherits the verbose name of the User.
        #This causes it to appear as "User" in the admin site.
        verbose_name = "Hospital Administrator";

    hospital_name = models.ForeignKey('Hospital')

    def save(self):
        LogItem(subject = self, action = 0, time = datetime.datetime.now()).save()
        User.save(self)

    def __repr__(self):
        return repr([self.first_name, self.last_name, self.username, self.password, self.email, self.salery,
                     self.hospital_name])


class Doctor(Employee):
    class Meta:
        #Without this, the Doctor class inherits the verbose name of the User.
        #This causes it to appear as "User" in the admin site.
        verbose_name = "Doctor";
        permissions = (("write_perscriptions", "Can write perscriptions for patients"),
                       ("give_diagnosis", "Can give a patient a diagnosis"))

    def __repr__(self):
        return repr([self.first_name, self.last_name, self.username, self.password, self.email, self.salery])

    def save(self):
        LogItem(subject = self, action = 0, time = datetime.datetime.now()).save()
        User.save(self)


class Nurse(Employee):
    class Meta:
        #Without this, the Nurse class inherits the verbose name of the User.
        #This causes it to appear as "User" in the admin site.
        verbose_name = "Nurse";

    def __repr__(self):
        return repr([self.first_name, self.last_name, self.username, self.password, self.email, self.salery])

    def save(self):
        LogItem(subject = self, action = 0, time = datetime.datetime.now()).save()
        User.save(self)


class SuperAdmin(User):
    def __init__(self, first_name, last_name, password, username, email):
        SuperAdmin = User.objects.create_user(username=username, password=password, first_name=first_name,
                                              last_name=last_name, email=email, is_staff=True, is_superuser=True)
        SuperAdmin.save()

    def __repr__(self):
        return repr([self.first_name, self.last_name, self.username, self.password, self.email, self.role, self.salery])


class ScheduleItem(models.Model):
    start_time=models.DateTimeField('Appointment Time')
    end_time=models.DateTimeField('End Time')
    description=models.TextField(max_length=500)
    person = models.ForeignKey(User, default=None, related_name="my_events")

    def create_schedule(self, StartTime, EndTime, Description):
        schedule = self.create(start_time = StartTime, end_time = EndTime, description = Description)
        return schedule

    def __str__(self):
        return self.description

    def save(self):
        LogItem(subject = self, action = 0, time = datetime.datetime.now()).save()
        models.Model.save(self)


class Appointment(models.Model):

    patient_name=models.CharField(max_length=250)
    doctor_name=models.CharField(max_length=250)
    hospital=models.CharField(max_length=250)

    def create_appointment(self, PatientName, DoctorsName, Hospital):
        appointment = self.create(patient_name=PatientName, doctor_name=DoctorsName, hospital=Hospital)
        return appointment

    def save(self):
        LogItem(subject=self, action=0, time=datetime.datetime.now()).save()
        models.Model.save(self)


class Hospital(models.Model):

    name=models.CharField(max_length=250)

    def create_hospital(self, HospitalName):
        hospital = self.create(name = HospitalName)
        return hospital


class InsurancePlan(models.Model):
    name = models.CharField(max_length=30)
    description = models.TextField(max_length=500)


class LogItem(models.Model):
    time = models.DateTimeField()
    subject = models.CharField(max_length=500)
    action = models.IntegerField()
    actor = models.ForeignKey(User, default=None, null=True)

    # def __init__(self, Time, Subject, ActionFlag, Actor = None):
    #     Item = super(LogItem,self).__init__(self,Time=Time, Subject=Subject, Action = LogItem.ActionDictionary[ActionFlag],Actor=Actor)
    #     Item.save(self)
    #     return Item

    def create_log_item(self, Actor, Action, Subject, Time):
        item = self.create(actor=Actor, action=Action, subject=Subject, time=Time)
        return item

    #post_init
    def actionString(self):
        action_dictionary = {0: 'CREATED', 1: 'EDITED', 2: 'DELETED', }
        return action_dictionary.get(self.action)


class Message(models.Model):

    sender = models.ForeignKey(User, default=None, null=True,related_name="sender")
    receiver= models.ForeignKey(User, default=None, null=True,related_name="receiver")
    text=models.TextField(max_length=300)


class Condition(models.Model):
    condition_name = models.CharField(max_length=250)
    condition_counter = models.IntegerField(default=0)

    def create_condition (self, condition_name, condition_counter):
        Condition = self.create(condition_name=condition_name, condition_counter=condition_counter)
        return Condition

    def increment_condition_counter(self):
        Condition.condition_counter +=1
        Condition.save()


class Drug(models.Model):
    drug_name = models.CharField(max_length=250)
    drug_counter = models.IntegerField(default=0)

    def create_drug(self, drug_name, drug_counter):
        Drug = self.create(drug_name=drug_name,drug_counter=drug_counter)
        return Drug

    def increment_drug_counter(self):
        Drug.drug_counter += 1
        Drug.save()


class Diagnosis(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    condition = models.ForeignKey(Condition, on_delete=models.CASCADE)
    date_of_diagnosis = models.DateField(default=0)
    doctors_notes = models.CharField(max_length=2500)

    def create_diagnosis(self, patient, doctor, condition, date_of_diagnosis, doctors_notes):
        Diagnosis = self.create(patient=patient, doctor=doctor,condition=condition,date_of_diagnosis=date_of_diagnosis,
                                doctors_notes=doctors_notes)
        Diagnosis.increment_condition_counter(condition)
        return Diagnosis


class Prescription(models.Model):
    drug = models.ForeignKey(Drug, on_delete=models.CASCADE)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    doctors_notes = models.CharField(max_length=2500)
    date_prescribed = models.DateField(default=0)

    def create_prescription(self, drug, patient, doctor, doctors_notes, date_prescribed):
        Prescription = self.create(drug = drug, patient = patient, doctor = doctor, doctors_notes = doctors_notes,
                                   date_prescribed = date_prescribed)
        Drug.increment_drug_counter(drug)
        return Prescription
