from django import forms
from django.forms.extras.widgets import SelectDateWidget
from .models import ScheduleItem, Patient, Doctor, Nurse, HospitalAdministrator, Message, Drug, Condition, Diagnosis,\
    Prescription


class LoginForm(forms.Form):
    """Form for logging a user in."""
    username = forms.CharField(label='Username', max_length=20)
    password = forms.CharField(label='Password', widget=forms.PasswordInput)


class CreatePatientForm(forms.ModelForm):
    """Form for entering info for a new patient"""
    class Meta:
        model = Patient
        fields = ['username',
                  'password',
                  'email',
                  'first_name',
                  'last_name',
                  'insurance_plan',
                  'date_of_birth',
                  'phone_number',
                  'contact_first_name',
                  'contact_last_name',
                  'contact_phone_number',]
        widgets = {'password': forms.PasswordInput(),
                   'date_of_birth': forms.extras.SelectDateWidget(
                       years=range(1900, 2016)[::-1]),}

    def __init__(self, *args, **kwargs):
        super(CreatePatientForm,self).__init__(*args, **kwargs)
        self.fields['insurance_plan'].label_from_instance = lambda insurance_plan: "%s" % (insurance_plan.name)


class PatientForm(CreatePatientForm):
    """Form for entering patient info"""
    class Meta(CreatePatientForm.Meta):
        exclude = ('password',)


class CreateDoctorForm(forms.ModelForm):
    """Form for entering info for a new Doctor"""
    class Meta:
        model = Doctor
        fields = ['username',
                  'password',
                  'email',
                  'first_name',
                  'last_name',
                  'salary',]
        widgets = {'password': forms.PasswordInput()}


class DoctorForm(CreateDoctorForm):
    """Form for entering Doctor info"""
    class Meta(CreateDoctorForm.Meta):
        exclude = ('password',)


class CreateNurseForm(forms.ModelForm):
    """Form for entering info for a new Nurse"""
    class Meta:
        model = Nurse
        fields = ['username',
                  'password',
                  'email',
                  'first_name',
                  'last_name',
                  'salary',]
        widgets = {'password': forms.PasswordInput()}


class NurseForm(CreateNurseForm):
    """Form for entering info for a new Nurse"""
    class Meta(CreateNurseForm.Meta):
        exclude = ('password',)


class CreateHospitalAdministratorForm(forms.ModelForm):
    """Form for entering info for a new Hospital Administrator"""
    class Meta:
        model = HospitalAdministrator
        fields = ['username',
                  'password',
                  'email',
                  'first_name',
                  'last_name',
                  'salary',
                  'hospital_name']
        widgets = {'password': forms.PasswordInput()}

    def __init__(self, *args, **kwargs):
        super(CreateHospitalAdministratorForm,self).__init__(*args, **kwargs)
        self.fields['hospital_name'].label_from_instance = lambda hospital: "%s" % (hospital.name)


class HospitalAdministratorForm(CreateHospitalAdministratorForm):
    """Form for entering Hospital Administrator info"""

    class Meta(CreateHospitalAdministratorForm.Meta):
        exclude = ('password',)


class AppointmentForm(forms.ModelForm):
    """Form for creating an appointment"""
    class Meta:
        model = ScheduleItem
        fields = ["start_time", "end_time", "description","person"]


class MessageForm(forms.ModelForm):

    class Meta:
        model = Message
        fields = ['receiver', 'text',]
        #fields=['receiver','text']


class CreateConditionForm(forms.ModelForm):
    """Form for creating a new condition"""
    class Meta:
        model = Condition
        fields = ['condition_name', ]


class CreateDrugForm(forms.ModelForm):
    """Form for creating a new drug"""
    class Meta:
        model=Drug
        fields = ['drug_name',]


class CreatePrescriptionForm(forms.ModelForm):
    """Form for creating a new prescription"""
    patient = forms.ModelChoiceField(queryset=Patient.objects.all(), empty_label=None) #Not sure if this is how its done
    class Meta:
        model=Prescription
        fields = ['doctors_notes','date_prescribed','drug']
        widget = {'date_prescribed': forms.extras.SelectDateWidget(years=range(2016)[::+1]),}

    def __init__(self, *args, **kwargs):
        super(CreatePrescriptionForm,self).__init__(*args, **kwargs)
        self.fields['drug'].label_from_instance = lambda drug: "%s" % (drug.drug_name)


class CreateDiagnosisForm(forms.ModelForm):
    """Form for creating a new diagnosis"""
    patient = forms.ModelChoiceField(queryset=Patient.objects.all(),empty_label=None)  # Not sure if this is how its done
    class Meta:
        model=Diagnosis
        fields = ['doctors_notes','condition','date_of_diagnosis']
        widget = {'date_of_diagnosis': forms.extras.SelectDateWidget(years=range(2016)[::+1]), }


    def __init__(self, *args, **kwargs):
        super(CreateDiagnosisForm,self).__init__(*args, **kwargs)
        self.fields['condition'].label_from_instance = lambda condition: "%s" % (condition.condition_name)
