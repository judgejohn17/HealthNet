from . import views
from django.conf.urls import url

urlpatterns = (
    url(r'^$', views.LoginFormView.as_view(success_url="/healthnet/landing"), name='login-form'),
    url(r'^logout/$', views.logout_view, name='logout_view'),
    url(r'^appointmentsJSON', views.send_appointments_as_JSON, name='JSON appointments'),
    url(r'^register/$', views.CreateAccountView.as_view(success_url="/healthnet"), name='create-account'),
    url(r'^register_doctor/$', views.CreateDoctorAccountView.as_view(success_url="/healthnet"),
        name='create-doctor-account'),
    url(r'^register_nurse/$', views.CreateNurseAccountView.as_view(success_url="/healthnet"),
        name='create-nurse-account'),
    url(r'^register_administrator/$', views.CreateAdministratorAccountView.as_view(success_url="/healthnet"),
        name='create-administrator-account'),
    url(r'^showcalendar/$', views.calendar_view, name='calendar'),
    url(r'^log/$', views.activity_log_view, name='activity-log'),
    url(r'^landing/$', views.landing_view, name='landing'),
    url(r'^appointment/$', views.CreateAppointmentView.as_view(success_url="/healthnet/landing"),
        name='create-appointment'),
    url(r'^patientlist/$', views.activity_log_view, name='view-patient-list'),
    url(r'^profile_(?P<pk>[0-9]+)/edit/$', views.UpdateProfileView.as_view(success_url="/healthnet/landing"),
        name='update-profile'),
    url(r'^profile_(?P<pk>[0-9]+)/$', views.ProfileDetailView.as_view(), name='profile-detail'),
    url(r'^send/$', views.send_message, name="send message"),
    url(r'^message/$', views.message_index, name="message index"),

    url(r'^create_drug/$', views.CreateDrugView.as_view(success_url="/healthnet/create_prescription"), name="create-drug"),
    url(r'^create_diagnosis/$', views.CreateDiagnosisView.as_view(success_url="/healthnet/landing"), name="create-diagnosis"),
    url(r'^create_prescription/$', views.CreatePrescriptionView.as_view(success_url="/healthnet/landing"),
        name="create-prescription"),
    url(r'^create_condition/$', views.CreateConditionView.as_view(success_url="/healthnet/create_diagnosis"), name="create-condition"),

)
