from django.shortcuts import render, redirect
from django.views.generic.edit import FormView, CreateView, UpdateView
from django.contrib.auth.models import User
from django.views.generic import DetailView
from healthnet.forms import LoginForm, AppointmentForm, PatientForm, CreatePatientForm, MessageForm, CreateDoctorForm, \
    CreateNurseForm, CreateHospitalAdministratorForm, CreateDrugForm, CreateDiagnosisForm, CreateConditionForm, \
    CreatePrescriptionForm
from django.http import HttpResponse, request
from django.contrib.auth import authenticate, login, logout
from .models import ScheduleItem, LogItem, Patient, Message, Doctor, Nurse, HospitalAdministrator, Condition, Drug, \
    Diagnosis, Prescription
import json
import sqlite3


def is_doctor(user):
    is_a_doctor = user.groups.all()[0].name == 'doctor'
    return is_a_doctor


def send_appointments_as_JSON(request):
    scheduled_items = ScheduleItem.objects.all()
    schedule_items_one=scheduled_items.filter(person=request.user)
    print(schedule_items_one)
    json_list = []

    for item in schedule_items_one:
        json_entry = {'title': item.description, 'start': str(item.start_time),'end':str(item.end_time)}
        json_list.append(json_entry)

    return HttpResponse(json.dumps(json_list), content_type='application/json')


def landing_view(request):
    """
    Display options based on user permissions (for example, give a
    user with permission to view the activity log an option to view
    the activity log)
    """
    if request.user.is_anonymous():
        return redirect('/healthnet/?next=%s' % request.path)
    return render(request, 'healthnet/landing.html', {"user": request.user})


def activity_log_view(request):
    """
    View all the activities that have been logged.
    """

    log = LogItem.objects.order_by('time').all();
    if request.user.is_anonymous():
        return redirect('/healthnet/?next=%s' % request.path)
    return render(request, 'healthnet/log.html', {'log': log})


def show_calendar(request):
    """
    Allows the user to view scheduled events. The calendar will only display
    events the user has permission to view.
    """
    if request.user.is_anonymous():
        return redirect('/healthnet/?next=%s' % request.path)
    list = sqlite3.connect('db.sqlite3')
    with list:
        X = []
        X.append(ScheduleItem.objects.all())

    return render(request, 'healthnet/calendar.html', {'name': X})


def calendar_view(request):
    """
    View all the Schedule Items
    """
    if request.user.is_anonymous():
        return redirect('/healthnet/?next=%s' % request.path)
    calendar_items = ScheduleItem.objects.all()
    x = {"Calendar": calendar_items}
    return render(request, 'healthnet/calendar.html', x)


def logout_view(request):
    logout(request)
    return redirect("/healthnet/")


class LoginFormView(FormView):
    """
    Log in to an existing account
    """

    template_name = 'healthnet/index.html'
    form_class = LoginForm

    def __repr__(self):
        return repr([self.template_name, self.form_class])

    def form_valid(self, form):
        login_user = authenticate(username=form["username"].value(), password=form["password"].value())
        if login_user is not None:
            if login_user.is_active:
                login(self.request, login_user)
                return redirect('landing/', {'username': login_user.username})
                #return render(self.request, 'healthnet/landing.html', {'username': login_user.username})
            else:
                return HttpResponse("Disabled Account")
        else:
            return render(self.request, 'healthnet/invalid_login.html')


def message_index(request):
    messages = Message.objects.filter(receiver__username=request.user.username)
    context = {'messages': messages}
    return render(request, 'healthnet/message_index.html', context=context)
    #return HttpResponse('<h1>Hey, you made it to the message page!</h1>')


def send_message(request):
    sent= False
    if request.method == "POST":
        message_form = MessageForm(data=request.POST)
        if message_form.is_valid():
            msg = message_form.save(commit=False)
            msg.sender = request.user
            msg.save()
            sent=True

        else:
            return HttpResponse(message_form.errors)

    message_form = MessageForm()
    context={'message_form':message_form, 'sent':sent}
    return render(request, 'healthnet/messages.html', context=context)


class CreateAccountView(CreateView):
    """
    Register a new patient account.
    """

    model = Patient
    template_name = 'healthnet/registration.html'
    form_class = CreatePatientForm

    def form_valid(self, form):
        form.instance.set_password(form.instance.password)
        return super(CreateAccountView, self).form_valid(form)

    def __repr__(self):
        return repr([self.template_name, self.form_class, self.model])


class CreateDoctorAccountView(CreateView):
    """
    Register a new Doctor account.
    """

    model = Doctor
    template_name = 'healthnet/registration.html'
    form_class = CreateDoctorForm

    def form_valid(self, form):
        form.instance.set_password(form.instance.password)
        return super(CreateDoctorAccountView, self).form_valid(form)

    def __repr__(self):
        return repr([self.template_name, self.form_class, self.model])


class CreateNurseAccountView(CreateView):
    """
    Register a new Doctor account.
    """

    model = Nurse
    template_name = 'healthnet/registration.html'
    form_class = CreateNurseForm

    def form_valid(self, form):
        form.instance.set_password(form.instance.password)
        return super(CreateNurseAccountView, self).form_valid(form)

    def __repr__(self):
        return repr([self.template_name, self.form_class, self.model])


class CreateAdministratorAccountView(CreateView):
    """
    Register a new Doctor account.
    """

    model = HospitalAdministrator
    template_name = 'healthnet/registration.html'
    form_class = CreateHospitalAdministratorForm

    def form_valid(self, form):
        form.instance.set_password(form.instance.password)
        return super(CreateAdministratorAccountView, self).form_valid(form)

    def __repr__(self):
        return repr([self.template_name, self.form_class, self.model])


class UpdateProfileView(UpdateView):
    """
    Provides a form with fields all of the user's data (excluding
    password).
    """

    model = Patient
    form_class = PatientForm
    template_name = 'healthnet/edit_profile.html'

    """def valid_login(self):
        if request.user.is_anonymous():
            return redirect('/login/?next=%s' % request.path)
        if request.user.isadoctor:
            login_user = request.user
            return render(request, 'registration/doctor_landing.html', {'username': login_user.username})
        elif request.user.isanurse == True:
            login_user = request.user
            return render(request, 'registration/nurse_landing.html', {'username': login_user.username})
        elif request.user.is_superuser:
            login_user = request.user
            return render(request, 'registration/admin_landing.html', {'username': login_user.username})
        else:
            login_user = request.user
            return render(request, 'registration/personal_landing.html', {'username': login_user.username})"""

    def __repr__(self):
        return repr([self.template_name, self.form_class, self.model])


class ProfileDetailView(DetailView):
    """
    Show information on a given patient. Offer an option to edit this
    information.
    """

    model = Patient
    template_name = 'healthnet/view_profile.html'

    """def valid_login(self):
        if request.user.is_anonymous():
            return redirect('/login/?next=%s' % request.path)
        if request.user.isadoctor:
            login_user = request.user
            return render(request, 'registration/doctor_landing.html', {'username': login_user.username})
        elif request.user.isanurse == True:
            login_user = request.user
            return render(request, 'registration/nurse_landing.html', {'username': login_user.username})
        elif request.user.is_superuser:
            login_user = request.user
            return render(request, 'registration/admin_landing.html', {'username': login_user.username})
        else:
            login_user = request.user
            return render(request, 'registration/personal_landing.html', {'username': login_user.username})"""

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super(ProfileDetailView, self).get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        object = self.get_object()
        context['patient'] = object
        return context

    def __repr__(self):
        return repr([self.template_name, self.model])


class CreateAppointmentView(CreateView):
    """
    Create a new appointment.
    """

    model = ScheduleItem
    template_name = 'healthnet/appointment.html'
    form_class = AppointmentForm

    """def valid_login(self):
        if request.user.is_anonymous():
            return redirect('/login/?next=%s' % request.path)
        if request.user.isadoctor:
            login_user = request.user
            return render(request, 'registration/doctor_landing.html', {'username': login_user.username})
        elif request.user.isanurse == True:
            login_user = request.user
            return render(request, 'registration/nurse_landing.html', {'username': login_user.username})
        elif request.user.is_superuser:
            login_user = request.user
            return render(request, 'registration/admin_landing.html', {'username': login_user.username})
        else:
            login_user = request.user
            return render(request, 'registration/personal_landing.html', {'username': login_user.username})"""

    def __repr__(self):
        return repr([self.template_name, self.form_class, self.model])

class CreateConditionView(CreateView):
    """
    Create a new condition
    """
    model = Condition
    template_name = 'healthnet/createcondition.html'
    form_class = CreateConditionForm

    def __repr__(self):
        return repr([self.template_name, self.form_class, self.model])

class CreateDrugView(CreateView):
    """
    Create a new drug
    """
    model = Drug
    template_name = 'healthnet/createdrug.html'
    form_class = CreateDrugForm

    def __repr__(self):
        return repr([self.template_name, self.form_class, self.model])

class CreateDiagnosisView(CreateView):
    """
    Create a new diagnosis
    """
    model = Diagnosis
    template_name = 'healthnet/creatediagnosis.html'
    form_class = CreateDiagnosisForm

    def __repr__(self):
        return repr([self.template_name, self.form_class, self.model])


class CreatePrescriptionView(CreateView):
    """
    Create a new prescription
    """
    model = Prescription
    template_name = 'healthnet/createprescription.html'
    form_class = CreatePrescriptionForm

    def __repr__(self):
        return repr([self.template_name, self.form_class, self.model])
